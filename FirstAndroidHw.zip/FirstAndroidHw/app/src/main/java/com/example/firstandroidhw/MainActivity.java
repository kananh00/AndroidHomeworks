package com.example.firstandroidhw;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void buttonClicked(View view) {
        Toast.makeText(this, "You clicked button, successfully", Toast.LENGTH_LONG).show();

        TextView tv = (TextView) findViewById(R.id.textView);
        tv.setText("It works, the text is changed!");
    }
}
