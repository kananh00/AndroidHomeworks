package com.example.androidhwlogging;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.v("myKey", "onCreate event happened.");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.v("myKey", "onStart event happened.");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v("myKey", "onPause event happened.");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.v("myKey", "onStop event happened.");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.v("myKey", "onDestroy event happened.");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.v("myKey", "onRestart event happened.");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.v("myKey", "onResume event happened.");
    }
}
